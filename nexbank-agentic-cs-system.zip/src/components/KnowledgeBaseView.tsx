import React, { useState } from 'react';
import { KNOWLEDGE_BASE_DOCUMENTS, queryKnowledgeBase } from '../data/knowledgeBase';
import { KnowledgeRetrievalResult } from '../types';
import {
  Zap,
  Search,
  BookOpen,
  Clock,
  ShieldCheck,
  FileText,
  Tag,
  CheckCircle2,
} from 'lucide-react';

export const KnowledgeBaseView: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('unauthorized fraud debit zero liability');
  const [retrievalResult, setRetrievalResult] = useState<KnowledgeRetrievalResult>(() =>
    queryKnowledgeBase('unauthorized fraud debit zero liability')
  );

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    if (q.trim()) {
      setRetrievalResult(queryKnowledgeBase(q));
    }
  };

  const sampleQueries = [
    'RBI zero liability unauthorized debit',
    'UPI failed transaction compensation 100 per day',
    'Fixed deposit interest rates senior citizen DICGC',
    'Card freeze instant rules RBI circular',
    'DigiLocker Aadhaar KYC masking',
    'RBI Integrated Ombudsman Scheme 2021',
  ];

  return (
    <div className="space-y-6">
      {/* Top Header with Latency Counter */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-amber-400" />
            <h2 className="text-base font-bold text-white tracking-tight">
              Dynamic Knowledge Base & Regulatory Index
            </h2>
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
              Sub-200ms Inverted Vector Engine
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Grounded directly on Reserve Bank of India (RBI) master circulars, NPCI payment specifications, and internal bank policies.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-950 border border-slate-800 px-3.5 py-2 rounded-xl text-xs flex items-center gap-2.5">
            <span className="text-slate-400">Current Search Latency:</span>
            <span className="font-mono text-emerald-400 font-bold text-sm">
              {retrievalResult.retrievalLatencyMs} ms
            </span>
            <span className="text-[10px] text-slate-500">(Target: &lt;200ms)</span>
          </div>
        </div>
      </div>

      {/* Real-time Query Benchmark Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4">
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Type any banking search query to test sub-200ms retrieval speed..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition"
          />
        </div>

        {/* Query Suggestion Pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-slate-500 text-[11px] font-medium mr-1">Suggested Benchmarks:</span>
          {sampleQueries.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSearch(q)}
              className={`px-2.5 py-1 rounded-lg text-[11px] transition ${
                searchQuery === q
                  ? 'bg-blue-600 text-white font-medium'
                  : 'bg-slate-800 hover:bg-slate-750 text-slate-300'
              }`}
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Search Results / Retrieved Articles */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>
            Retrieved <strong className="text-white">{retrievalResult.documents.length}</strong> regulatory documents for query "{retrievalResult.query}"
          </span>
          <span className="font-mono text-emerald-400">
            Speed: {retrievalResult.retrievalLatencyMs}ms (Sub-200ms SLA PASSED)
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {retrievalResult.documents.map(({ document: doc, score, matchSnippet }) => (
            <div
              key={doc.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm hover:border-slate-700 transition space-y-3"
            >
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-[11px] font-bold text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-800/40">
                      {doc.id}
                    </span>
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      {doc.domain.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <h3 className="font-bold text-white text-base">{doc.title}</h3>
                </div>

                <div className="flex items-center gap-3 text-xs">
                  <span className="bg-emerald-950/80 text-emerald-300 border border-emerald-800/50 px-2.5 py-1 rounded-lg font-mono font-bold">
                    Score: {score}
                  </span>
                  <span className="text-slate-400 font-mono flex items-center gap-1">
                    <Clock className="h-3 w-3 text-slate-500" />
                    TAT: {doc.turnaroundTimeHours}h
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800 font-medium">
                "{matchSnippet}"
              </p>

              {/* Document Full Content */}
              <div className="text-xs text-slate-300 whitespace-pre-line bg-slate-850/60 p-4 rounded-xl border border-slate-800/80 leading-relaxed">
                {doc.content}
              </div>

              {/* Footer Meta & Grounding */}
              <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                <div className="flex items-center gap-1 text-indigo-300">
                  <ShieldCheck className="h-3.5 w-3.5 text-indigo-400" />
                  <span>Mandate: <strong className="text-white">{doc.rbiCircularRef || 'NexBank Core Rule'}</strong></span>
                </div>

                <div className="flex items-center gap-1.5">
                  <Tag className="h-3 w-3 text-slate-500" />
                  <div className="flex gap-1 flex-wrap">
                    {doc.keywords.slice(0, 4).map((kw, i) => (
                      <span key={i} className="bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">
                        #{kw}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
