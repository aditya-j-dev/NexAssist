import React, { useState } from 'react';
import { INTENT_TAXONOMY, INTENT_DOMAINS } from '../data/intentTaxonomy';
import { IntentDomain } from '../types';
import { classifyHierarchicalIntent } from '../utils/dialogueEngine';
import {
  Layers,
  Search,
  Sparkles,
  ShieldAlert,
  Lock,
  Clock,
  CheckCircle2,
  Filter,
} from 'lucide-react';

export const TaxonomyView: React.FC = () => {
  const [selectedDomain, setSelectedDomain] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [testUtterance, setTestUtterance] = useState('My UPI payment failed but money was debited from my account');
  const [testResult, setTestResult] = useState(() => classifyHierarchicalIntent('My UPI payment failed but money was debited from my account'));

  const handleTestClassifier = (query: string) => {
    setTestUtterance(query);
    if (query.trim()) {
      setTestResult(classifyHierarchicalIntent(query));
    }
  };

  const filteredIntents = INTENT_TAXONOMY.filter((intent) => {
    const matchesDomain = selectedDomain === 'ALL' || intent.domain === selectedDomain;
    const matchesSearch =
      searchQuery === '' ||
      intent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      intent.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      intent.sampleUtterances.some((u) => u.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesDomain && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="h-5 w-5 text-blue-400" />
            <h2 className="text-base font-bold text-white tracking-tight">
              26-Intent Hierarchical NLU Taxonomy
            </h2>
            <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
              6 Banking Domains
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Production-grade banking classification hierarchy with slot models, authentication tiers, and regulatory SLA mappings.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl text-xs flex items-center gap-2">
            <span className="text-slate-400">Total Intents:</span>
            <strong className="text-white font-mono text-sm">{INTENT_TAXONOMY.length}</strong>
          </div>
        </div>
      </div>

      {/* Interactive NLU Classifier Sandbox */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-blue-950/40 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="h-4 w-4 text-amber-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-white">
            Live Hierarchical NLU Classifier Sandbox
          </h3>
        </div>
        <p className="text-xs text-slate-400 mb-3">
          Enter any sample customer sentence to test real-time intent mapping, confidence scoring, and slot extraction.
        </p>

        <div className="flex flex-col sm:flex-row gap-2 mb-4">
          <input
            type="text"
            value={testUtterance}
            onChange={(e) => handleTestClassifier(e.target.value)}
            placeholder="e.g. Someone stole my card and debited ₹8499 at 11pm"
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={() => handleTestClassifier(testUtterance)}
            className="bg-blue-600 hover:bg-blue-500 text-white text-xs px-4 py-2 rounded-xl font-medium transition"
          >
            Classify Query
          </button>
        </div>

        {/* Classifier Result Display */}
        {testResult && (
          <div className="bg-slate-950/90 border border-slate-800 p-4 rounded-xl flex flex-wrap items-center justify-between gap-4 text-xs">
            <div>
              <div className="text-[11px] text-slate-400 uppercase tracking-wider mb-0.5">
                Classified Domain & Intent
              </div>
              <div className="font-bold text-white text-sm flex items-center gap-2">
                <span className="bg-blue-600/30 text-blue-300 border border-blue-500/40 px-2 py-0.5 rounded text-xs">
                  {testResult.domain}
                </span>
                <span>{INTENT_TAXONOMY.find((i) => i.id === testResult.intentId)?.name || testResult.intentId}</span>
              </div>
            </div>

            <div className="flex items-center gap-6">
              <div>
                <div className="text-[11px] text-slate-400 uppercase tracking-wider mb-0.5">
                  NLU Confidence Score
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full ${
                        testResult.confidence >= 0.8
                          ? 'bg-emerald-500'
                          : testResult.confidence >= 0.65
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${testResult.confidence * 100}%` }}
                    />
                  </div>
                  <span className="font-mono font-bold text-white">
                    {Math.round(testResult.confidence * 100)}%
                  </span>
                </div>
              </div>

              <div>
                <div className="text-[11px] text-slate-400 uppercase tracking-wider mb-0.5">
                  Extracted Entities / Slots
                </div>
                <div className="font-mono text-emerald-400">
                  {Object.keys(testResult.extractedSlots).length > 0
                    ? JSON.stringify(testResult.extractedSlots)
                    : 'None extracted'}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex overflow-x-auto gap-1.5 pb-1">
          <button
            onClick={() => setSelectedDomain('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium transition whitespace-nowrap ${
              selectedDomain === 'ALL'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            All Domains ({INTENT_TAXONOMY.length})
          </button>
          {INTENT_DOMAINS.map((d) => (
            <button
              key={d.domain}
              onClick={() => setSelectedDomain(d.domain)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition whitespace-nowrap ${
                selectedDomain === d.domain
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {d.title}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="h-3.5 w-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search intents or utterances..."
            className="w-full sm:w-64 bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Intent Cards Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredIntents.map((intent) => (
          <div
            key={intent.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 shadow-sm transition flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-750">
                  {intent.domainTitle}
                </span>

                <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                  <Clock className="h-3 w-3 text-slate-500" />
                  SLA: {intent.slaMinutes}m
                </span>
              </div>

              <h4 className="font-bold text-white text-sm mb-1.5">{intent.name}</h4>
              <p className="text-xs text-slate-400 mb-3 leading-relaxed">
                {intent.description}
              </p>

              {/* Sample Utterances */}
              <div className="mb-3">
                <div className="text-[10px] uppercase font-semibold text-slate-500 mb-1">
                  Training Utterances
                </div>
                <div className="space-y-1">
                  {intent.sampleUtterances.slice(0, 2).map((ut, idx) => (
                    <div
                      key={idx}
                      className="text-[11px] text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800/80 italic"
                    >
                      "{ut}"
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
              <span className="text-slate-400 flex items-center gap-1">
                Auth:
                <strong className={
                  intent.requiredAuthLevel === 'BIOMETRIC_2FA'
                    ? 'text-emerald-400'
                    : intent.requiredAuthLevel === 'TPIN_VERIFIED'
                    ? 'text-blue-400'
                    : 'text-slate-300'
                }>
                  {intent.requiredAuthLevel}
                </strong>
              </span>

              {intent.isAccountWriteAction && (
                <span className="text-amber-400 font-semibold flex items-center gap-1 text-[10px]">
                  <Lock className="h-3 w-3" /> Write Action
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
